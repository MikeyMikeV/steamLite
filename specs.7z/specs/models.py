from django.db import models
from django.core.validators import MinValueValidator
from games.models import Game

class SpecsMixin(models.Model):
    os = models.ForeignKey('OS', on_delete=models.PROTECT)
    processor = models.ForeignKey("Processor", on_delete=models.PROTECT)
    
    class Meta:
        abstract = True

class MinimumRequirements(SpecsMixin):
    game = models.ForeignKey(Game, on_delete=models.CASCADE)
    

class RecommendedRequirements(SpecsMixin):
    game = models.ForeignKey(Game, on_delete=models.CASCADE)

class OS(models.Model):
    name = models.CharField(max_length=128)
    BIT_CHOICES = (
        (32, 32),
        (64, 64),
    )
    bit = models.IntegerField(default=2, choices=BIT_CHOICES)

    def __str__(self):
        return f'{self.name} ({self.bit}bit)'
    
class Processor(models.Model):
    BRAND_CHOICES = (
        ('Intel', 'Intel'),
        ('AMD', 'AMD'),
    )
    CORE_CHOICES = (
        ('Core', 'Core'),
        ('Dual', 'Dual-Core'),
        ('Quad_core', 'Quad_core'),
    )
    brand = models.CharField(max_length = 128, choices = BRAND_CHOICES) 
    core_type = models.CharField(max_length = 128, choices = CORE_CHOICES, null=True, blank=True)
    name = models.CharField(max_length = 128)
    model = models.CharField(max_length = 50)
    speed = models.DecimalField(
        validators=(
            MinValueValidator(1, 'Введенное значение ниже допустимого'),
        ),
        max_digits=2,
        decimal_places=1,
        help_text='GHz'
    )

    def __str__(self) -> str:
        return f'{self.brand} {self.core_type} {self.model}'

# class Graphics(models.Model):
#     brand
#     name
#     model
#     vram
